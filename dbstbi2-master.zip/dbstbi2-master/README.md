# stbi
Tugas Information Retrieval
Materi :<br>
<ol>
<li>Tokenisasi</li>
<li>Stemming Porter</li>
<li>Stemming Nazief Adriani</li>
<li>Stopword Removal</li>
<li>Index Invert</li>
</ol>
